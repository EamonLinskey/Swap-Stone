document.addEventListener("DOMContentLoaded", function(event) {
	document.querySelector('.updateCollection').onclick = function() {
		location.href="profile/updateCollection"
	}

	document.querySelector('.wishList').onclick = function() {
		location.href="profile/wishList"
	}

});